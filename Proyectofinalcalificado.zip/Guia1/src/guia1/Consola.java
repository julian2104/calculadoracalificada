package guia1;

import java.util.Scanner;

public class Consola {

    public static void main(String[] args) {
        Scanner ingreso = new Scanner(System.in);
        Calculadora calcu1 = new Calculadora();

        while (true) {
            System.out.print("Ingrese el numero 1: ");
            float a = ingreso.nextFloat();
            System.out.print("Ingrese el numero 2: ");
            float b = ingreso.nextFloat();
            calcu1.num1 = a;
            calcu1.num2 = b;

            System.out.println("Seleccione la operacion que desea realizar:");
            System.out.println("1. Suma");
            System.out.println("2. Resta");
            System.out.println("3. Multiplicacion");
            System.out.println("4. Division");
            System.out.println("5. Coseno");
            System.out.println("6. Seno");
            System.out.println("7. Tangente");
            System.out.println("8. Raiz enesima");
            System.out.println("9. Potencia");
            System.out.println("10. Calcular IVA");
            System.out.println("11. Salir");

            int opcion = ingreso.nextInt();
            if (opcion == 11) {
                System.out.println("Saliendo de la calculadora...");
                break;
            } else if (opcion < 1 || opcion > 10) {
                System.out.println("Opción inválida. Por favor, seleccione una opción válida.");
                continue;
            }

            switch (opcion) {
                case 1:
                    calcu1.suma();
                    System.out.println("La suma de los numeros es: " + calcu1.result);
                    break;
                case 2:
                    calcu1.resta();
                    System.out.println("La resta de los numeros es: " + calcu1.result);
                    break;
                case 3:
                    calcu1.mult();
                    System.out.println("La multiplicacion entre los numeros es: " + calcu1.result);
                    break;
                case 4:
                    calcu1.div();
                    System.out.println("La division entre los numeros es: " + calcu1.result);
                    break;
                case 5:
                    calcu1.cos(b);
                    System.out.println("El coseno del numero es: " + calcu1.result);
                    break;
                case 6:
                    calcu1.sen(b);
                    System.out.println("El seno del numero es: " + calcu1.result);
                    break;
                case 7:
                    calcu1.tan(b);
                    System.out.println("La tangente del numero es: " + calcu1.result);
                    break;
                case 8:
                    calcu1.raiz(b, a);
                    System.out.println("La raiz enesima del numero es: " + calcu1.result);
                    break;
                case 9:
                    calcu1.pot(a, b);
                    System.out.println("La potencia del numero es: " + calcu1.result);
                    break;
                case 10:
                    System.out.println("Ingrese el costo de un producto");
                    float d = ingreso.nextFloat();
                    calcu1.costoproduc = d;
                    System.out.println("Ingrese el valor del iva");
                    float e = ingreso.nextFloat();
                    calcu1.porceniva = e;
                    calcu1.iva();
                    System.out.println("El iva de los numeros ingresados es: " + calcu1.result);
                    break;
            }
        }
    }
}